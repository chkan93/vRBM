- [x] Pass the Weight and Bias as InputData

- [x] Duplicate the designs 

- [x] Remove All the Parameters, and Make sure that the simulation still works

- synthesis, and see the output netlist.
